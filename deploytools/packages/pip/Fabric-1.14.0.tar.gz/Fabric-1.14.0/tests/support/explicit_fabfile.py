__all__ = ['foo']

def foo():
    pass

def bar():
    pass
